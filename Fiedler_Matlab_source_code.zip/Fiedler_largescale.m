%%  Implementation of a distributed algorithm for computation of the Fiedler vector of a network
%%  Version: 1.1
%%  Requires additional file: creategraph.m

%  More info can be found in the paper

%  A. Bertrand and M. Moonen, "Distributed computation of the Fiedler
%  vector with application to topology inference in ad hoc networks"

% and on the website http://homes.esat.kuleuven.be/~abertran


%% Copyright (c) 2012, Alexander Bertrand
% All rights reserved.
% Redistribution and use in source and binary forms, with or
% without modification, are permitted provided that the
% following conditions are met:
% 1) Redistributions of source code must retain the above copyright
% notice and this list of conditions.
% 2) Redistributions in binary form must reproduce the above copyright
% notice and this list of conditions in the documentation and/or other
% materials provided with the distribution.
% 3) The name of its contributors may not be used to endorse or promote
% products derived from this software without specific prior written
% permission.
%
% Contact: alexander.bertrand@esat.kuleuven.be (please report bugs)

%After running this file, run the file makefigures_paper.m to create figures


clear all
close all
nbMCruns=1000; %number of Monte-Carlo trials
nbiters=2000; %number of iterations performed by the algorithm in each MC trial
epsil=1e-1; %value for epsilon (see below)
guaranteed_conv=0; %set to 1 to guarantee convergence (possible slower convergence)
N=250; %value for N. Will be overwritten if guaranteed_conv==1;

errorloc=zeros(nbMCruns,nbiters); %to store the error in each iteration
normxloc=errorloc; %to store the norm of x in each iteration
rloc=zeros(nbiters,1); %to store the value of r_k=r in each iteration (only most recent MC run is kept)
tic
for MCrun=1:nbMCruns
    
    
    clustersize=50;
    crosslinks=5; %number of cross links between clusters
    A1=creategraph(4,clustersize,4);
    A2=creategraph(4,clustersize,4);
    A3=creategraph(4,clustersize,4);
    A=blkdiag(A1,A2,A3);
    %%% create 5 links between A1 and A2
    for k=1:5
        a1=ceil(clustersize*rand(1));
        a2=clustersize+ceil(clustersize*rand(1));
        A(a1,a2)=1;
        A(a2,a1)=1;
    end
    %%%create 10 links between A1 and A3
    for k=1:20
        a1=ceil(clustersize*rand(1));
        a2=2*clustersize+ceil(clustersize*rand(1));
        A(a1,a2)=1;
        A(a2,a1)=1;
    end
    %%%create 5 links between A3 and A2
    for k=1:5
        a1=2*clustersize+ceil(clustersize*rand(1));
        a2=clustersize+ceil(clustersize*rand(1));
        A(a1,a2)=1;
        A(a2,a1)=1;
    end
    neighbors=sum(A,2);
    K=size(A,1);
    
    D=diag(sum(A));
    L=D-A; %Laplacian matrix
    
    [u,v]=svd(L);
    Fiedlervector=u(:,end-1);
    lambda2=v(end-1,end-1);
    
    
    alpha=min(K,2*max(diag(D)));
    M=eye(K)-1/alpha*L;
    
    v=diag(v);
    T=log(v(1:end-2)/lambda2)./log((alpha-lambda2)./(alpha-v(1:end-2)));
    if guaranteed_conv==1
    N=max(ceil(max(T))+40); %this should certainly yield convergence
    end
    
    P=K;
    
    
    x=randn(K,1);
    theta=(K/(K-1))*min(diag(D));
    r=(1-1/3*theta/alpha)*ones(size(x));
    p=r(1);
    rmin=1-theta/alpha; %minimal value of r
    
    for i=0:nbiters-1
        
        if rem(i,P)==0
            pushvaluev=r(1);
        end
        if rem(i,P)==P-1
            p=pushvaluev;
        end        
        if rem(i,N)==0
            if abs(1-r)<1e-5
                t=epsil;
            else
                t=abs(1-p);
            end
        end
        y=x;
        for k=1:K
            if rem(i,N)==0
                x(k)=1/(t*alpha)*(neighbors(k)*y(k)-A(k,:)*y);
            else
                x(k)=1/p*((1-1/alpha*neighbors(k))*y(k)+1/alpha*A(k,:)*y);
            end
        end
        for k=1:K
            if rem(i,N)~=0
                r(k)=min(max(r(k)+1/y(k)*(p*x(k)-r(k)*y(k)),rmin),1); %adapt...
            end
        end
        q=r;
        for k=1:K
            r(k)=min(max((1/(1+neighbors(k)))*q(k)+1/(1+neighbors(k))*A(k,:)*q,rmin),1); %...then combine (ATC, Cattivelli)
        end
        
        errorloc(MCrun,i+1)=min(norm(x/norm(x)-Fiedlervector),norm(x/norm(x)+Fiedlervector));
        normxloc(MCrun,i+1)=norm(x);
        rloc(i+1)=p;
        
    end
    
    %%%%%DRAW INTERMEDIATE PLOT (can be commented out)
    subplot(3,1,1)
    p1=quantile(errorloc(1:MCrun,:),[.25 .5 .75],1);
    semilogy(p1(2,:),'r')
    hold on
    semilogy(p1(1,:),'--')
    semilogy(p1(3,:),'--')
    hold off
    xlabel('iteration')
    title('median and quartiles of error (after normalization)')
    subplot(3,1,2)
    p2=quantile(normxloc(1:MCrun,:),[.25 .5 .75],1);
    semilogy(p2(2,:),'r')
    hold on
    semilogy(p2(1,:),'--')
    semilogy(p2(3,:),'--')
    hold off
    title('median and quartiles of norm of x')
    xlabel('iteration')
    subplot(3,1,3)
    plot(rloc)
    title('value of r (most recent MC run)')
    xlabel('iteration')
    drawnow
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%Save every now and then
    if rem(MCrun,50)==0
        toc
        save('dataMCruns_largescale','errorloc','normxloc','MCrun')
        MCrun
        tic
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
end
toc
save('dataMCruns_largescale','errorloc','normxloc','MCrun')
