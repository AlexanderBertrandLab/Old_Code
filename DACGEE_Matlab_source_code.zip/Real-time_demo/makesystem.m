%Initialisation of system

close all
D=10;    %dimension of latent random process

nbsensnode=15*ones(1,nbnodes); %number of sensors at each node (one element for each node)
noisepower=0.1; %additive spatially uncorrelated white noise with uniform distribution
nbsamples=10000; %number of observations per iteration of the DACMEE algorithm

nbsens=sum(nbsensnode); %total number of sensors

d1=rand(nbsamples,D); %random latent process
d1=d1-ones(nbsamples,1)*mean(d1);
d2=rand(nbsamples,D); %same random latent process, but new observations
d2=d2-ones(nbsamples,1)*mean(d2);


for k=1:nbnodes
    Ainit{k}=rand(D,nbsensnode(k))-0.5; %random mixture
    noise1{k}=sqrt(noisepower)*(rand(nbsamples,nbsensnode(k))); %random noise
    noise1{k}=noise1{k}-ones(nbsamples,1)*mean(noise1{k});
    noise2{k}=sqrt(noisepower)*(rand(nbsamples,nbsensnode(k))); %same random noise, but new observations
    noise2{k}=noise2{k}-ones(nbsamples,1)*mean(noise2{k});
    
end



