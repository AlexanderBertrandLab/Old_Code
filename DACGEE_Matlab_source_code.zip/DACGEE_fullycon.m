%%  Monte-Carlo simulations of DACGEE in fully-connected WSNs

%%  Version: 1.0

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Copyright (c) 2013, Alexander Bertrand
% All rights reserved.
% Redistribution and use in source and binary forms, with or
% without modification, are permitted provided that the
% following conditions are met:
% 1) Redistributions of source code must retain the above copyright
% notice and this list of conditions.
% 2) Redistributions in binary form must reproduce the above copyright
% notice and this list of conditions in the documentation and/or other
% materials provided with the distribution.
% 3) The name of its contributors may not be used to endorse or promote
% products derived from this software without specific prior written
% permission.
%
% Contact: alexander.bertrand@esat.kuleuven.be (please report bugs)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% NOTE: this code may take more than a day to finish. Reduce nbMCruns to reduce simulation time

clear all
close all

nbMCruns=200; %number of MC runs

tellernodes=0;
for nbnodes=[10 20 50] %simulate for networks with different number of nodes
    tellernodes=tellernodes+1;
    tellerQ=0;
    
    if nbnodes==10
        Qrange=[1:2:5]; %which values of Q need to be simulated
    else
        Qrange=1;
    end
    for Q=Qrange %simulate for different number of eigenvectors (Q in paper)
        
        nbiter=1000; %number of DACGEE iterations
        tellerQ=tellerQ+1;
        
        Jser{tellernodes,tellerQ}=zeros(nbMCruns,nbiter); %track value of objective function Tr(X^H Ryy X)
        Wnormser{tellernodes,tellerQ}=zeros(nbMCruns,nbiter); %track MSE with respect to true value of eigenvalues
        Jopt{tellernodes,tellerQ}=zeros(nbMCruns,1); %optimal value of objective function Tr(X^H Ryy X)
        tic
        for MCrun=1:nbMCruns
           
            makesystem %create data
            nbsens=sum(nbsensnode); %number of sensors
            
            clear dnode
            clear U
            clear V
            
            %compute observations for each node
            for k=1:nbnodes
                A{k}=Ainit{k}(:,1:nbsensnode(k));
                U{k}=d1*A{k}+noise1{k};
                V{k}=[zeros(size(d2,1),Q) d2(:,Q+1:end)]*A{k}+noise2{k};
            end
            
            
            Ufull=[]; %full vector U
            Vfull=[]; %full vector V
            for k=1:nbnodes
                Ufull=[Ufull U{k}];
                Vfull=[Vfull V{k}];
            end
            
            %Optimal solution:
            clear wopt
            Ruu=1/nbsamples*conj(Ufull'*Ufull);
            Rvv=1/nbsamples*conj(Vfull'*Vfull);
            [B,s]=eig(Ruu,Rvv);
            [magweg,ind]=sort(abs(diag(s)),'descend');
            wopt=B(:,ind(1:Q));
            Jopt{tellernodes,tellerQ}(MCrun)=abs(trace(wopt'*Ruu*wopt))/nbsamples; %optimal value of objective function
            winit=randn(size(wopt));
            clear wnode
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%                     DACGEE algorithm
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            clear w %note: W is X in the paper
            clear W 
            teller=1;
            wold=winit;
            for k=1:nbnodes
                W{k}=winit(teller:teller+nbsensnode(k)-1,:); % X_k^i from the paper
                w=winit; %full X^i from the paper
                teller=teller+nbsensnode(k);
            end
            clear teller
            
            for i=0:nbiter-1
                k=rem(i,nbnodes)+1;
                
                %update node k
                Compressor=blkdiag(eye(nbsensnode(k)),W{1:k-1},W{k+1:end});
                Umink=horzcat(U{1:k-1},U{k+1:end});
                Ucompressed=horzcat(U{k},Umink*conj(blkdiag(W{1:k-1},W{k+1:end}))); %utilde in the paper
                Vmink=horzcat(V{1:k-1},V{k+1:end});
                Vcompressed=horzcat(V{k},Vmink*conj(blkdiag(W{1:k-1},W{k+1:end}))); %vtilde in the paper
                
                Ruucompressed=1/nbsamples*conj(Ucompressed'*Ucompressed); %R_{utilde utilde} in the paper
                Rvvcompressed=1/nbsamples*conj(Vcompressed'*Vcompressed); %R_{utilde utilde} in the paper

                [B,s]=eig(Ruucompressed,Rvvcompressed); %compute eigenvalues and eigenvectors
                [notneeded,ind]=sort(abs(diag(s)),'descend'); %sort eigenvalues in descending order
                WGnew=B(:,ind(1:Q)); %select Q principal eigenvectors
                Wkold=W{k};
                W{k}=WGnew(1:nbsensnode(k),:); %new estimate of X_k^{i+1}
                
                %resolve sign ambiguity (internally)
                for q=1:Q
                    if sum(sum((Wkold(:,q)-W{k}(:,q)).^2))>sum(sum((-Wkold(:,q)-W{k}(:,q)).^2))
                        W{k}(:,q)=-W{k}(:,q);
                        WGnew(:,q)=-WGnew(:,q);
                    end
                end
                
                teller=1;
                for q=1:k-1
                    W{q}=W{q}*WGnew(nbsensnode(k)+teller:nbsensnode(k)+teller+Q-1,:);
                    teller=teller+Q;
                end
                for q=k+1:nbnodes
                    W{q}=W{q}*WGnew(nbsensnode(k)+teller:nbsensnode(k)+teller+Q-1,:);
                    teller=teller+Q;
                end
                
                % Stack the W{k}'s to obtain complete eigenvectors
                wold=w;
                teller=1;
                for q=1:nbnodes
                    w(teller:teller+nbsensnode(q)-1,:)=W{q}(:,1:Q);
                    teller=teller+nbsensnode(q);
                end
                
                %resolve sign ambiguity (for plotting)
                for q=1:Q
                    if sum(sum((wopt(:,q)-w(:,q)).^2))>sum(sum((-wopt(:,q)-w(:,q)).^2))
                        w(:,q)=-w(:,q);
                    end
                end
                
                Jser{tellernodes,tellerQ}(MCrun,i+1)=abs(trace(w'*Ruu*w))/nbsamples;
                Wnormser{tellernodes,tellerQ}(MCrun,i+1)= sum(sum(abs(wopt-w).^2))/(size(w,1)*size(w,2));
                
%                 %%% Show intermediate plot of estimate (only first column of w)
%                          plot(wopt(:,1),'r')
%                          hold on
%                          plot(w(:,1))
%                          ylim([1.2*min(real(wopt(:,1))) 1.2*max(real(wopt(:,1)))]);
%                          hold off
%                          drawnow
                
            end
            MCrun
            if rem(MCrun,20)==0 %save once in a while
               save('simresults','Jser','Jopt','Wnormser','nbiter','MCrun')
            end
        end
        toc

    end
end
save('simresults','Jser','Jopt','Wnormser','nbiter','MCrun')

