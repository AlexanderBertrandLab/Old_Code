%%  Monte-Carlo simulations of DACMEE in fully-connected WSNs

%%  Version: 1.0

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Copyright (c) 2013, Alexander Bertrand
% All rights reserved.
% Redistribution and use in source and binary forms, with or
% without modification, are permitted provided that the
% following conditions are met:
% 1) Redistributions of source code must retain the above copyright
% notice and this list of conditions.
% 2) Redistributions in binary form must reproduce the above copyright
% notice and this list of conditions in the documentation and/or other
% materials provided with the distribution.
% 3) The name of its contributors may not be used to endorse or promote
% products derived from this software without specific prior written
% permission.
%
% Contact: alexander.bertrand@esat.kuleuven.be (please report bugs)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% NOTE: this code may take more than a day to finish. Reduce nbMCruns to reduce simulation time

clear all
close all

nbMCruns=200; %number of MC runs

tellernodes=0;
for nbnodes=[10 20 50] %simulate for networks with different number of nodes
    tellernodes=tellernodes+1;
    tellerQ=0;
    
    if nbnodes==10
        Qrange=[1:2:5]; %which values of Q need to be simulated
    else
        Qrange=1;
    end
    for Q=Qrange %simulate for different number of eigenvectors (Q in paper)
        
        nbiter=1500; %number of DACMEE iterations
        tellerQ=tellerQ+1;
        
        Jser{tellernodes,tellerQ}=zeros(nbMCruns,nbiter); %track value of objective function Tr(X^H Ryy X)
        errorser{tellernodes,tellerQ}=zeros(nbMCruns,nbiter); %track reconstruction MSE on Y (omitted, severely slows down code)
        Wnormser{tellernodes,tellerQ}=zeros(nbMCruns,nbiter); %track MSE with respect to true value of eigenvalues
        Jopt{tellernodes,tellerQ}=zeros(nbMCruns,1); %optimal value of objective function Tr(X^H Ryy X)
        tic
        for MCrun=1:nbMCruns
           
            makesystem %create data
            nbsens=sum(nbsensnode); %number of sensors
            
            clear dnode
            clear Y
            clear d
            
            %compute observations for each node
            for k=1:nbnodes
                d=dinit;
                A{k}=Ainit{k}(:,1:nbsensnode(k));
                Y{k}=d*A{k}+noise{k};
            end
            
            
            Yfull=[]; %full vector Y
            for k=1:nbnodes
                Yfull=[Yfull Y{k}];
            end
            
            %Optimal solution:
            clear wopt
            Ryy=1/nbsamples*conj(Yfull'*Yfull);
            [u,s]=eig(Ryy);
            [magweg,ind]=sort(abs(diag(s)),'descend');
            wopt=u(:,ind(1:Q));
            Jopt{tellernodes,tellerQ}(MCrun)=abs(trace(wopt'*Ryy*wopt))/nbsamples; %optimal value of objective function
            erroropt{tellernodes,tellerQ}(MCrun)=sum(sum(abs(Yfull-(Yfull*conj(wopt))*wopt.').^2))/(size(Yfull,1)*size(Yfull,2)); %compression/reconstruction with exact eigenvectors
            winit=randn(size(wopt));
            clear wnode
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%                     DACMEE algorithm
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            clear w %note: W is X in the paper
            clear W 
            teller=1;
            wold=winit;
            for k=1:nbnodes
                W{k}=winit(teller:teller+nbsensnode(k)-1,:); % X_k^i from the paper
                w=winit; %full X^i from the paper
                teller=teller+nbsensnode(k);
            end
            clear teller
            
            for i=0:nbiter-1
                k=rem(i,nbnodes)+1;
                
                %update node k
                Compressor=blkdiag(eye(nbsensnode(k)),W{1:k-1},W{k+1:end});
                Ymink=horzcat(Y{1:k-1},Y{k+1:end});
                Ycompressed=horzcat(Y{k},Ymink*conj(blkdiag(W{1:k-1},W{k+1:end}))); %ytilde in the paper
                
                Ryycompressed=conj(Ycompressed'*Ycompressed); %R_{ytilde ytilde} in the paper
                Lambdasquared=(Compressor'*Compressor);
                L=chol(Lambdasquared); %this is Lambda in the paper
                LRL=(L'\Ryycompressed)/L; %computes \overline{R}_q^i from the paper
                [u,s]=eig(LRL); %compute eigenvalues and eigenvectors
                [notneeded,ind]=sort(abs(diag(s)),'descend'); %sort eigenvalues in descending order
                WGnewtransformed=u(:,ind(1:Q)); %select Q principal eigenvectors
                WGnew=L\WGnewtransformed;
                Wkold=W{k};
                W{k}=WGnew(1:nbsensnode(k),:); %new estimate of X_k^{i+1}
                
                %resolve sign ambiguity (internally)
                for q=1:Q
                    if sum(sum((Wkold(:,q)-W{k}(:,q)).^2))>sum(sum((-Wkold(:,q)-W{k}(:,q)).^2))
                        W{k}(:,q)=-W{k}(:,q);
                        WGnew(:,q)=-WGnew(:,q);
                    end
                end
                
                teller=1;
                for q=1:k-1
                    W{q}=W{q}*WGnew(nbsensnode(k)+teller:nbsensnode(k)+teller+Q-1,:);
                    teller=teller+Q;
                end
                for q=k+1:nbnodes
                    W{q}=W{q}*WGnew(nbsensnode(k)+teller:nbsensnode(k)+teller+Q-1,:);
                    teller=teller+Q;
                end
                
                % Stack the W{k}'s to obtain complete eigenvectors
                wold=w;
                teller=1;
                for q=1:nbnodes
                    w(teller:teller+nbsensnode(q)-1,:)=W{q}(:,1:Q);
                    teller=teller+nbsensnode(q);
                end
                
                %resolve sign ambiguity (for plotting)
                for q=1:Q
                    if sum(sum((wopt(:,q)-w(:,q)).^2))>sum(sum((-wopt(:,q)-w(:,q)).^2))
                        w(:,q)=-w(:,q);
                    end
                end
                
                Jser{tellernodes,tellerQ}(MCrun,i+1)=abs(trace(w'*Ryy*w))/nbsamples;
                % errorser{tellernodes,tellerQ}(MCrun,i+1)=sum(sum(abs(Yfull-(Yfull*conj(w))*w.').^2))/(size(Yfull,1)*size(Yfull,2)); % OMITTED %severely slows down code
                Wnormser{tellernodes,tellerQ}(MCrun,i+1)= sum(sum(abs(wopt-w).^2))/(size(w,1)*size(w,2));
                
%                 %%% Show intermediate plot of estimate (only first column of w)
%                          plot(wopt(:,1),'r')
%                          hold on
%                          plot(w(:,1))
%                          ylim([1.2*min(real(wopt(:,1))) 1.2*max(real(wopt(:,1)))]);
%                          hold off
%                          drawnow
                
            end
            MCrun
            if rem(MCrun,20)==0 %save once in a while
               save('simresults_new','Jser','Jopt','errorser','Wnormser','nbiter','MCrun','erroropt')
            end
        end
        toc

    end
end
save('simresults_new','Jser','Jopt','errorser','Wnormser','nbiter','MCrun','erroropt')

