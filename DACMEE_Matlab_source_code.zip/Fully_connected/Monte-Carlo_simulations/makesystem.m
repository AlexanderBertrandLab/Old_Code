%Initialisation of system

close all
D=10;    %dimension of latent random process

nbsensnode=15*ones(1,nbnodes); %number of sensors at each node (one element for each node)
noisepower=0.1; %additive spatially uncorrelated white noise with uniform distribution
nbsamples=10000; %number of observations per iteration of the DACMEE algorithm

nbsens=sum(nbsensnode); %total number of sensors

dinit=rand(nbsamples,D); %random latent process
dinit=dinit-ones(nbsamples,1)*mean(dinit);

for k=1:nbnodes
    Ainit{k}=rand(D,nbsensnode(k))-0.5; %random mixture
    noise{k}=sqrt(noisepower)*(rand(nbsamples,nbsensnode(k)));
    noise{k}=noise{k}-ones(nbsamples,1)*mean(noise{k});
    
end



