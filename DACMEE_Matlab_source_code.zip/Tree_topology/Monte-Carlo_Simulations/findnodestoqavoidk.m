%This function is applied to check if a node t has a path to node q that
%does not contain k


%function [checkflag]=findnodestoqavoidk(checkflag,terminated,connectionmatrix,t,q,k)

%Inputs:
%checkflag        = must be 1 at first call
%terminated         =J-dim vector with a 1 at indices of all nodes that are already visited
%                   should be all-zero in first call
%connectionmatrix   = if element (i,j)==1, this means that there is an arc 
%                   from node i to node j.
%t                  = node in which the path starts
%q                  = node to which a path has to be found
%k                  = node through which the path cannot go

%Outputs:
%checkflag              = 1 if a path has found from t to q without passing k, 0
%                   otherwise

function [checkflag,terminated]=findnodestoqavoidk(checkflag,terminated,connectionmatrix,t,q,k)
terminated(t)=1;
if t==k
    checkflag=0;
    terminated=ones(length(terminated),1);
elseif t==q
    checkflag=1;
    terminated=ones(length(terminated),1);
else
    neighbours=find(connectionmatrix(t,:).*(1-terminated')==1);
    for j=neighbours
        [temp,terminated]=findnodestoqavoidk(checkflag,terminated,connectionmatrix,j,q,k);
        checkflag=checkflag*temp;
    end
end
end