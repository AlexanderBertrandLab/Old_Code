
%%First run DACMEE_tree before running this code

close all
clear all

load simresults_new
 showiters=300;
 
 fonts=20;
 fontslegend=16;
 scrsz = get(0,'ScreenSize');
figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)])

subplot(2,1,1)
for n=1:size(Wnormser,2)
p2{n}=mean(Jser{1,n}(1:MCrun,1:showiters),1);
p3{n}=mean(Jopt{1,n}(1:MCrun));
end
plot(p2{1},'r','LineWidth',2);
hold on
plot(p3{1}*ones(length(p2{1})),'r--','LineWidth',2);
plot(p2{2},'g','LineWidth',2);
plot(p3{2}*ones(length(p2{2})),'g--','LineWidth',2);
plot(p2{3},'b','LineWidth',2);
plot(p3{3}*ones(length(p2{2})),'b--','LineWidth',2);

xlabel('iteration','Interpreter','latex','Fontsize',fonts)
ylabel('Objective function','Interpreter','latex','Fontsize',fonts)
ylim([0 7e-4])
set(gca,'Fontsize',fontslegend)
 h=legend('Objective function','Optimal value of objective function');
 set(h,'Fontsize',fontslegend,'Location','SouthEast')

 % Create textbox
annotation('textbox',...
    [0.411689655172414 0.626546681664793 0.0491567398119123 0.0314960629921282],...
    'Interpreter','latex',...
    'String',{'Q=1'},...
    'FontSize',18,...
    'FontName','Abyssinica SIL',...
    'FitBoxToText','off',...
    'LineStyle','none');

% Create textbox
annotation('textbox',...
    [0.411689655172414 0.749403824521936 0.0491567398119123 0.0314960629921282],...
    'Interpreter','latex',...
    'String',{'Q=3'},...
    'FontSize',18,...
    'FontName','Abyssinica SIL',...
    'FitBoxToText','off',...
    'LineStyle','none');

% Create textbox
annotation('textbox',...
    [0.411689655172414 0.862137232845897 0.0491567398119123 0.0314960629921282],...
    'Interpreter','latex',...
    'String',{'Q=5'},...
    'FontSize',18,...
    'FontName','Abyssinica SIL',...
    'FitBoxToText','off',...
    'LineStyle','none');
 

subplot(2,1,2)
for n=1:size(Wnormser,2)
p1{n}=quantile(Wnormser{1,n}(1:MCrun,1:showiters),[.25 .5 .75],1);
end
    semilogy(p1{1}(2,:),'r','LineWidth',2);
    hold on
    semilogy(p1{2}(2,:),'g','LineWidth',2);
    semilogy(p1{3}(2,:),'b','LineWidth',2);
    semilogy(p1{1}(1,:),'r--','LineWidth',2);
    semilogy(p1{1}(3,:),'r--','LineWidth',2);
    



xlabel('iteration','Interpreter','latex','Fontsize',fonts)
ylabel('MSE over entries of $\mathbf{X}^i$','Interpreter','latex','Fontsize',fonts)
ylim([1e-10 5e-2])
set(gca,'Fontsize',fontslegend)
 h=legend('Median (Q=1)','Median (Q=3)','Median (Q=5)','25% and 75% percentiles (only for Q=1)');
 set(h,'Fontsize',fontslegend,'Location','SouthWest')

cd figures
print_pdf('Convergence_tree')
cd ..

clear p2
clear p3
figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)])
showiters=1000;
subplot(2,1,1)
for n=1:size(Wnormser,1)
p2{n}=mean(Jser{n,1}(1:MCrun,1:showiters),1);
p3{n}=mean(Jopt{n,1}(1:MCrun));
end
plot(p2{1},'r','LineWidth',2);
hold on
plot(p3{1}*ones(length(p2{1})),'r--','LineWidth',2);
plot(p2{2},'g','LineWidth',2);
plot(p3{2}*ones(length(p2{2})),'g--','LineWidth',2);
plot(p2{3},'b','LineWidth',2);
plot(p3{3}*ones(length(p2{2})),'b--','LineWidth',2);

xlabel('iteration','Interpreter','latex','Fontsize',fonts)
ylabel('Objective function','Interpreter','latex','Fontsize',fonts)
ylim([0 7e-4])
set(gca,'Fontsize',fontslegend)

 h=legend('Objective function','Optimal value of objective function');
 set(h,'Fontsize',fontslegend,'Location','SouthEast')

  % Create textbox
annotation('textbox',...
    [0.411689655172414 0.62 0.0491567398119123 0.0314960629921282],...
    'Interpreter','latex',...
    'String',{'K=10'},...
    'FontSize',18,...
    'FontName','Abyssinica SIL',...
    'FitBoxToText','off',...
    'LineStyle','none');

% Create textbox
annotation('textbox',...
    [0.411689655172414 0.686 0.0491567398119123 0.0314960629921282],...
    'Interpreter','latex',...
    'String',{'K=20'},...
    'FontSize',18,...
    'FontName','Abyssinica SIL',...
    'FitBoxToText','off',...
    'LineStyle','none');

% Create textbox
annotation('textbox',...
    [0.411689655172414 0.85 0.0491567398119123 0.0314960629921282],...
    'Interpreter','latex',...
    'String',{'K=50'},...
    'FontSize',18,...
    'FontName','Abyssinica SIL',...
    'FitBoxToText','off',...
    'LineStyle','none');
 

subplot(2,1,2)
for n=1:size(Wnormser,1)
p1{n}=quantile(Wnormser{n,1}(1:MCrun,1:showiters),[.25 .5 .75],1);
end
    semilogy(p1{1}(2,:),'r','LineWidth',2);
    hold on
    semilogy(p1{1}(1,:),'r--','LineWidth',2);
    semilogy(p1{1}(3,:),'r--','LineWidth',2);
    
    semilogy(p1{2}(2,:),'g','LineWidth',2);
    semilogy(p1{3}(2,:),'b','LineWidth',2);
    
    semilogy(p1{2}(1,:),'g--','LineWidth',2);
    semilogy(p1{2}(3,:),'g--','LineWidth',2);
    
    semilogy(p1{3}(1,:),'b--','LineWidth',2);
    semilogy(p1{3}(3,:),'b--','LineWidth',2);
    
xlabel('iteration','Interpreter','latex','Fontsize',fonts)
ylabel('MSE over entries of $\mathbf{X}^i$','Interpreter','latex','Fontsize',fonts)
ylim([1e-15 5e-2])

  % Create textbox
annotation('textbox',...
    [0.318 0.3 0.0491567398119123 0.0314960629921282],...
    'Interpreter','latex',...
    'String',{'K=10'},...
    'FontSize',18,...
    'FontName','Abyssinica SIL',...
    'FitBoxToText','off',...
    'LineStyle','none');

  % Create textbox
annotation('textbox',...
    [0.6 0.31 0.0491567398119123 0.0314960629921282],...
    'Interpreter','latex',...
    'String',{'K=20'},...
    'FontSize',18,...
    'FontName','Abyssinica SIL',...
    'FitBoxToText','off',...
    'LineStyle','none');

  % Create textbox
annotation('textbox',...
    [0.8 0.4 0.0491567398119123 0.0314960629921282],...
    'Interpreter','latex',...
    'String',{'K=50'},...
    'FontSize',18,...
    'FontName','Abyssinica SIL',...
    'FitBoxToText','off',...
    'LineStyle','none');

set(gca,'Fontsize',fontslegend)
 h=legend('Median','25% and 75% percentiles');
 set(h,'Fontsize',fontslegend,'Location','SouthWest')
 
cd figures
print_pdf('Convergence_differentnbnodes_tree')
cd ..

%%%%OMITTED BECAUSE COMPUTATION OF errorser SIGNIFICANTLY SLOWS DOWN THE
%%%%CODE
% figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)])
% for n=1:size(Wnormser,2)
% p2{n}=mean(errorser{1,n}(1:MCrun,1:showiters),1);
% p3{n}=mean(erroropt{1,n}(1:MCrun));
% end
% plot(p2{1},'r','LineWidth',2);
% hold on
% plot(p3{1}*ones(length(p2{1})),'r--','LineWidth',2);
% plot(p2{2},'g','LineWidth',2);
% plot(p3{2}*ones(length(p2{2})),'g--','LineWidth',2);
% plot(p2{3},'b','LineWidth',2);
% plot(p3{3}*ones(length(p2{2})),'b--','LineWidth',2);
% 
% xlabel('iteration','Interpreter','latex','Fontsize',fonts)
% ylabel('MSE for PCA-based reconstruction of $\mathbf{Y}$','Interpreter','latex','Fontsize',fonts)
% 
%  h=legend('Reconstruction error with DACMEE','Optimal reconstruction error');
%  set(h,'Fontsize',fontslegend,'Location','SouthEast')

