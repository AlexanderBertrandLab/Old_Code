%%  DACMEE implementation in WSNs with a tree topology

%%  Version: 1.0

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Copyright (c) 2013, Alexander Bertrand
% All rights reserved.
% Redistribution and use in source and binary forms, with or
% without modification, are permitted provided that the
% following conditions are met:
% 1) Redistributions of source code must retain the above copyright
% notice and this list of conditions.
% 2) Redistributions in binary form must reproduce the above copyright
% notice and this list of conditions in the documentation and/or other
% materials provided with the distribution.
% 3) The name of its contributors may not be used to endorse or promote
% products derived from this software without specific prior written
% permission.
%
% Contact: alexander.bertrand@esat.kuleuven.be (please report bugs)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all


nbnodes=20; %number of nodes (K in paper)
Q=3;
nbiter=200; %number of DACMEE iterations

congraph=creategraph(3,nbnodes); %adjacency matrix of the network graph (defines the links), creategraph(3,...) yields a tree topology

tic

makesystem %create data
nbsens=sum(nbsensnode); %number of sensors

clear dnode
clear Y
clear d

%compute observations for each node
for k=1:nbnodes
    d=dinit;
    A{k}=Ainit{k}(:,1:nbsensnode(k));
    Y{k}=d*A{k}+noise{k};
end


Yfull=[]; %full vector Y
for k=1:nbnodes
    Yfull=[Yfull Y{k}];
end

%Optimal solution:
clear wopt
Ryy=1/nbsamples*conj(Yfull'*Yfull);
[u,s]=eig(Ryy);
[magweg,ind]=sort(abs(diag(s)),'descend');
wopt=u(:,ind(1:Q));
winit=randn(size(wopt));
clear wnode

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                     DACMEE algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear w %note: W is X in the paper
clear W
teller=1;
wold=winit;
for k=1:nbnodes
    W{k}=winit(teller:teller+nbsensnode(k)-1,:); % X_k^i from the paper
    w=winit; %full X^i from the paper
    teller=teller+nbsensnode(k);
end
clear teller

for i=0:nbiter-1
    k=rem(i,nbnodes)+1;
    
    %update node k
    
    
    [notneeded,neighbors]=find(congraph(k,:)==1); %find neighbors of node k
    
    %%create Ytilde and Lambda
    
    Ytilde=Y{k}; %z-signals will be added later
    tel=1;
    clear Lambdasquaredpart %clear previous version
    for q=neighbors
        branch{q}=[];
        %find all nodes in the branch attached to node k that contains node q
        for t=1:nbnodes
            if findnodestoqavoidk(1,zeros(nbnodes,1),congraph,t,q,k)==1
                branch{q}=[branch{q} t];
            end
        end
        Lambdasquaredbranch=zeros(Q); %Lambda corresponding to the branch
        Ybranch=zeros(size(Yfull,1),Q);
        for l=branch{q}
            Lambdasquaredbranch=Lambdasquaredbranch+W{l}'*W{l};
            Ybranch=Ybranch+Y{l}*conj(W{l});
        end
        Lambdasquaredpart{tel}=Lambdasquaredbranch; %part of Lambdasquared
        tel=tel+1;
        Ytilde=[Ytilde Ybranch];
    end
    Lambdasquared=blkdiag(eye(nbsensnode(k)),blkdiag(Lambdasquaredpart{:}));
    
    
    Ryycompressed=conj(Ytilde'*Ytilde); %R_{ytilde ytilde} in the paper
    
    L=chol(Lambdasquared); %this is Lambda in the paper
    LRL=(L'\Ryycompressed)/L; %computes \overline{R}_q^i from the paper
    [u,s]=eig(LRL); %compute eigenvalues and eigenvectors
    [notneeded,ind]=sort(abs(diag(s)),'descend'); %sort eigenvalues in descending order
    WGnewtransformed=u(:,ind(1:Q)); %select Q principal eigenvectors
    WGnew=L\WGnewtransformed;
    Wkold=W{k};
    W{k}=WGnew(1:nbsensnode(k),:); %new estimate of X_k^{i+1}
    
    %resolve sign ambiguity (internally)
    for q=1:Q
        if sum(sum((Wkold(:,q)-W{k}(:,q)).^2))>sum(sum((-Wkold(:,q)-W{k}(:,q)).^2))
            W{k}(:,q)=-W{k}(:,q);
            WGnew(:,q)=-WGnew(:,q);
        end
    end
    
    teller=1;
    for q=neighbors
        for l=branch{q}
            W{l}=W{l}*WGnew(nbsensnode(k)+teller:nbsensnode(k)+teller+Q-1,:);
        end
        teller=teller+Q;
        
    end
    
    % Stack the W{k}'s to obtain complete eigenvectors
    wold=w;
    teller=1;
    for q=1:nbnodes
        w(teller:teller+nbsensnode(q)-1,:)=W{q}(:,1:Q);
        teller=teller+nbsensnode(q);
    end
    
    %resolve sign ambiguity (for plotting)
    for q=1:Q
        if sum(sum((wopt(:,q)-w(:,q)).^2))>sum(sum((-wopt(:,q)-w(:,q)).^2))
            w(:,q)=-w(:,q);
        end
    end
    
    
    %%% Show intermediate plot of estimate (only first column of w)
    plot(wopt(:,1),'r')
    hold on
    plot(w(:,1))
    ylim([1.2*min(real(wopt(:,1))) 1.2*max(real(wopt(:,1)))]);
    hold off
    legend('Exact principal eigenvector','Estimated principal eigenvector')
    drawnow
    
end
toc
        

