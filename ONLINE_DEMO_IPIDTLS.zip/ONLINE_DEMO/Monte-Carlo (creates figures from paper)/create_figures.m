%% Generate figures for IPI-D-TLS paper

% !!! Requires to run PI_based_DTLS_montecarlo_vardimN.m and
% PI_based_DTLS_montecarlo_varSZmu.m first to generate .mat files

%% Copyright (c) 2011, Alexander Bertrand
% All rights reserved.
% Redistribution and use in source and binary forms, with or
% without modification, are permitted provided that the
% following conditions are met:
% 1) Redistributions of source code must retain the above copyright
% notice and this list of conditions.
% 2) Redistributions in binary form must reproduce the above copyright
% notice and this list of conditions in the documentation and/or other
% materials provided with the distribution.
% 3) The name of its contributors may not be used to endorse or promote
% products derived from this software without specific prior written
% permission.
%
% Contact: alexander.bertrand@esat.kuleuven.be (please report bugs)



% This is an attachement to the paper
%
%  [1] A. Bertrand and M. Moonen, "Low-complexity distributed total least squares estimation in ad hoc sensor networks"
%
%  More info on the website http://homes.esat.kuleuven.be/~abertran


close all
clear all
scrsz = get(0,'ScreenSize');

%%%%%%%%%%%%Different fixed mu's
load alles_smalldim
MCiter=1000;
nbnodes=20;

figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)])
set(gca,'FontSize',18)
hold on
a=plot(sum(sum(meanerror1oi,2),3)/(MCiter*nbnodes),'k--','LineWidth',4,'Color',[.4 .4 .4])
b=plot(sum(sum(meanerrormu25,2),3)/(MCiter*nbnodes),'k:','LineWidth',4)
c=plot(sum(sum(meanerrormu10,2),3)/(MCiter*nbnodes),'r','LineWidth',4)
d=plot(sum(sum(meanerrormu5,2),3)/(MCiter*nbnodes),'b--','LineWidth',2.5)
e=plot(sum(sum(meanerrormu1,2),3)/(MCiter*nbnodes),'k','LineWidth',2,'Color',[.5 .5 .5])
f=plot(sum(sum(meanerrorDTLS,2),3)/(MCiter*nbnodes),'b-.','LineWidth',3)

h_leg=legend([a;b;c;d;e;f],'IPI-D-TLS with decreasing \mu     ','IPI-D-TLS with fixed \mu=0.3','IPI-D-TLS with fixed \mu=0.2','IPI-D-TLS with fixed \mu=0.1','IPI-D-TLS with fixed \mu=0.02','D-TLS with fixed \mu=1')
set(h_leg,'FontSize',24);
legend boxoff
xlabel('# iterations')
ylabel('error')
ylim([0 0.9])
box on

clear all
scrsz = get(0,'ScreenSize');



%%%%%%%%%%%%Different fixed mu's
load alles_xdim
MCiter=500;
nbnodes=20;


figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)])
set(gca,'FontSize',18)
hold on
a=plot(sum(sum(squeeze(meanerror(:,:,1,:)),2),3)/(MCiter*nbnodes),'k--','LineWidth',4,'Color',[.4 .4 .4])
b=plot(sum(sum(squeeze(meanerror(:,:,2,:)),2),3)/(MCiter*nbnodes),'k:','LineWidth',4)
c=plot(sum(sum(squeeze(meanerror(:,:,3,:)),2),3)/(MCiter*nbnodes),'r','LineWidth',3)
d=plot(sum(sum(squeeze(meanerror(:,:,4,:)),2),3)/(MCiter*nbnodes),'b--','LineWidth',2.5)

h_leg=legend([a;b;c;d],'IPI-D-TLS with N=10, \mu=0.2','IPI-D-TLS with N=50, \mu=1','IPI-D-TLS with N=100, \mu=2','IPI-D-TLS with N=200, \mu=4      ')
set(h_leg,'FontSize',24);
legend boxoff
xlabel('# iterations')
ylabel('error')
ylim([0 0.9])
box on