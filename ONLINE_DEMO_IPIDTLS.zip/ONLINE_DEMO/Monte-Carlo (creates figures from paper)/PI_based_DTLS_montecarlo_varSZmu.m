%% Simulate multiple Monte-Carlo experiments for IPI-D-TLS for different stepsizes mu

%%!!! code is not cleaned up (see folder 'Visual demo' for cleaner code)
%%!!! generates a large .mat file (>500 MB)
%%!!! run time can be hours/days

%% Copyright (c) 2011, Alexander Bertrand
% All rights reserved.
% Redistribution and use in source and binary forms, with or
% without modification, are permitted provided that the
% following conditions are met:
% 1) Redistributions of source code must retain the above copyright
% notice and this list of conditions.
% 2) Redistributions in binary form must reproduce the above copyright
% notice and this list of conditions in the documentation and/or other
% materials provided with the distribution.
% 3) The name of its contributors may not be used to endorse or promote
% products derived from this software without specific prior written
% permission.
%
% Contact: alexander.bertrand@esat.kuleuven.be (please report bugs)


% This is an attachement to the paper
%
%  [1] A. Bertrand and M. Moonen, "Low-complexity distributed total least squares estimation in ad hoc sensor networks",
%  internal report K.U. Leuven ESAT/SCD-SISTA
%
%  More info on the website http://homes.esat.kuleuven.be/~abertran

clear all
close all

nbnodes=20;
xdim=10;



fixedmu=1; %stepsize for grad descent
nbiters=400;

meancostDTLS=zeros(nbiters,nbnodes,1000);
meanerrorDTLS=zeros(nbiters,nbnodes,1000);
meancost1oi=zeros(nbiters,nbnodes,1000);
meanerror1oi=zeros(nbiters,nbnodes,1000);

meancostmu25=zeros(nbiters,nbnodes,1000);
meanerrormu25=zeros(nbiters,nbnodes,1000);
meancostmu10=zeros(nbiters,nbnodes,1000);
meanerrormu10=zeros(nbiters,nbnodes,1000);
meancostmu5=zeros(nbiters,nbnodes,1000);
meanerrormu5=zeros(nbiters,nbnodes,1000);
meancostmu1=zeros(nbiters,nbnodes,1000);
meanerrormu1=zeros(nbiters,nbnodes,1000);

meanoptcost=0;

close all

for MCiter=1:1000
    MCiter
    
    %1=fully connected
    %2=line topology
    %3=tree topology
    %4=random connected graph
    congraph=creategraph(4,nbnodes,3);
    createsystem;
    
    
    %%%Optimal solution
    Rtot=zeros(xdim,xdim);
    for k=1:nbnodes
        Rtot=Rtot+R{k};
        [u,s,a]=svd(R{k});
        mineigRk(k)=s(end,end);
    end
    [u,s,a]=svd(Rtot); 
    xopt=a(:,end);
    stot=s(end,end);
    %resolve sign ambiguity
    [nn,index]=max(abs(xopt));
    if xopt(index)<0
        xopt=-xopt;
    end
    optcost=xopt'*Rtot*xopt;
    meanoptcost=meanoptcost+optcost;
    
    
    %%%%classic D-TLS with mu=xdim/10
    clear Lambda
    for k=1:nbnodes
        Lambda{k}=zeros(xdim,xdim);
    end
    error=zeros(nbiters,nbnodes);
    cost=zeros(nbiters,nbnodes);
    for i=1:nbiters
        for k=1:nbnodes
            
            M=R{k}+Lambda{k}';
            [a,s]=eigs(M,1,'SA');
            x{k}=a(:,end);
            X{k}=x{k}*x{k}';
        end
        mu=xdim/10;
        for k=1:nbnodes
            Lambda{k}=Lambda{k}+mu*sum(congraph(k,:))*X{k};
            for n=1:nbnodes
                if congraph(k,n)==1 && k~=n
                    Lambda{k}=Lambda{k}-mu*X{n}; 
                end
            end
        end
        for k=1:nbnodes
            x{k}=X{k}(:,1)/sqrt(X{k}(1,1));
            [nn,index]=max(abs(x{k}));
            if norm(x{k}-xopt)>norm(-x{k}-xopt)
                x{k}=-x{k};
            end
            error(i,k)=min(norm(x{k}-xopt),norm(-x{k}-xopt));
            cost(i,k)=x{k}'*Rtot*x{k};
        end
    end
    meancostDTLS(:,:,MCiter)=cost;
    meanerrorDTLS(:,:,MCiter)=error;
    
    %%%%PI-based D-TLS, mu=0.3*1/i *xdim/10
    clear P
    clear x
    
    for k=1:nbnodes
        P{k}=inv(R{k});
        x{k}=ones(xdim,1);
        x{k}=x{k}/norm(x{k});
    end
    error=zeros(nbiters,nbnodes);
    cost=zeros(nbiters,nbnodes);
    for i=1:nbiters
        mu=3*(1/i^(0.7))*xdim/100;
        for k=1:nbnodes
            x{k}=P{k}*x{k};
            x{k}=x{k}/norm(x{k});
        end
        
        for k=1:nbnodes
            for n=1:nbnodes
                if congraph(k,n)==1 && k~=n
                    uv=sqrt(mu)*x{n};
                    uv2=P{k}*uv;
                    P{k}=P{k}+(1/(1-uv'*uv2))*uv2*uv2';
                end
            end
            uv=sqrt(mu*sum(congraph(k,:)))*x{k};
            uv2=P{k}*uv;
            P{k}=P{k}-(1/(1+uv'*uv2))*uv2*uv2';
        end
        for k=1:nbnodes
            if norm(x{k}-xopt)>norm(-x{k}-xopt)
                x{k}=-x{k};
            end
            error(i,k)=min(norm(x{k}-xopt),norm(-x{k}-xopt));
            cost(i,k)=x{k}'*Rtot*x{k};
        end
    end
    meancost1oi(:,:,MCiter)=cost;
    meanerror1oi(:,:,MCiter)=error;
    
    %%%%PI-based D-TLS, fixed mu=0.3*xdim/10 (REMARK:mu=0.3 is more or less on the
    %%%%boundary of stability. mu=0.4 also often works well, but sometimes
    %%%%unstable behavior in some cases.)
    clear P
    clear x
    mu=3*xdim/100;
    for k=1:nbnodes
        P{k}=inv(R{k});
        x{k}=ones(xdim,1);
        x{k}=x{k}/norm(x{k});
    end
    error=zeros(nbiters,nbnodes);
    cost=zeros(nbiters,nbnodes);
    for i=1:nbiters
        for k=1:nbnodes
            x{k}=P{k}*x{k};
            x{k}=x{k}/norm(x{k});
        end
        
        for k=1:nbnodes
            for n=1:nbnodes
                if congraph(k,n)==1 && k~=n
                    uv=sqrt(mu)*x{n};
                    uv2=P{k}*uv;
                    P{k}=P{k}+(1/(1-uv'*uv2))*uv2*uv2';
                end
            end
            uv=sqrt(mu*sum(congraph(k,:)))*x{k};
            uv2=P{k}*uv;
            P{k}=P{k}-(1/(1+uv'*uv2))*uv2*uv2';
        end
        for k=1:nbnodes
            if norm(x{k}-xopt)>norm(-x{k}-xopt)
                x{k}=-x{k};
            end
            error(i,k)=min(norm(x{k}-xopt),norm(-x{k}-xopt));
            cost(i,k)=x{k}'*Rtot*x{k};
        end
    end
    meancostmu25(:,:,MCiter)=cost;
    meanerrormu25(:,:,MCiter)=error;
    
        %%%%PI-based D-TLS, fixed mu=0.2*xdim/10
    clear P
    clear x
    mu=2*xdim/100;
    for k=1:nbnodes
        P{k}=inv(R{k});
        x{k}=ones(xdim,1);
        x{k}=x{k}/norm(x{k});
    end
    error=zeros(nbiters,nbnodes);
    cost=zeros(nbiters,nbnodes);
    for i=1:nbiters
        for k=1:nbnodes
            x{k}=P{k}*x{k};
            x{k}=x{k}/norm(x{k});
        end
        
        for k=1:nbnodes
            for n=1:nbnodes
                if congraph(k,n)==1 && k~=n
                    uv=sqrt(mu)*x{n};
                    uv2=P{k}*uv;
                    P{k}=P{k}+(1/(1-uv'*uv2))*uv2*uv2';
                end
            end
            uv=sqrt(mu*sum(congraph(k,:)))*x{k};
            uv2=P{k}*uv;
            P{k}=P{k}-(1/(1+uv'*uv2))*uv2*uv2';
        end
        for k=1:nbnodes
            if norm(x{k}-xopt)>norm(-x{k}-xopt)
                x{k}=-x{k};
            end
            error(i,k)=min(norm(x{k}-xopt),norm(-x{k}-xopt));
            cost(i,k)=x{k}'*Rtot*x{k};
        end
    end
    meancostmu10(:,:,MCiter)=cost;
    meanerrormu10(:,:,MCiter)=error;
   
        %%%%PI-based D-TLS, fixed mu=0.1*xdim/10
    clear P
    clear x
    mu=1*xdim/100;
    for k=1:nbnodes
        P{k}=inv(R{k});
        x{k}=ones(xdim,1);
        x{k}=x{k}/norm(x{k});
    end
    error=zeros(nbiters,nbnodes);
    cost=zeros(nbiters,nbnodes);
    for i=1:nbiters
        for k=1:nbnodes
            x{k}=P{k}*x{k};
            x{k}=x{k}/norm(x{k});
        end
        
        for k=1:nbnodes
            for n=1:nbnodes
                if congraph(k,n)==1 && k~=n
                    uv=sqrt(mu)*x{n};
                    uv2=P{k}*uv;
                    P{k}=P{k}+(1/(1-uv'*uv2))*uv2*uv2';
                end
            end
            uv=sqrt(mu*sum(congraph(k,:)))*x{k};
            uv2=P{k}*uv;
            P{k}=P{k}-(1/(1+uv'*uv2))*uv2*uv2';
        end
        for k=1:nbnodes
            if norm(x{k}-xopt)>norm(-x{k}-xopt)
                x{k}=-x{k};
            end
            error(i,k)=min(norm(x{k}-xopt),norm(-x{k}-xopt));
            cost(i,k)=x{k}'*Rtot*x{k};
        end
    end
    meancostmu5(:,:,MCiter)=cost;
    meanerrormu5(:,:,MCiter)=error;
    
        %%%%PI-based D-TLS, fixed mu=0.02*xdim/10
    clear P
    clear x
    mu=0.2*xdim/100;
    for k=1:nbnodes
        P{k}=inv(R{k});
        x{k}=ones(xdim,1);
        x{k}=x{k}/norm(x{k});
    end
    error=zeros(nbiters,nbnodes);
    cost=zeros(nbiters,nbnodes);
    for i=1:nbiters
        for k=1:nbnodes
            x{k}=P{k}*x{k};
            x{k}=x{k}/norm(x{k});
        end
        
        for k=1:nbnodes
            for n=1:nbnodes
                if congraph(k,n)==1 && k~=n
                    uv=sqrt(mu)*x{n};
                    uv2=P{k}*uv;
                    P{k}=P{k}+(1/(1-uv'*uv2))*uv2*uv2';
                end
            end
            uv=sqrt(mu*sum(congraph(k,:)))*x{k};
            uv2=P{k}*uv;
            P{k}=P{k}-(1/(1+uv'*uv2))*uv2*uv2';
        end
        for k=1:nbnodes
            if norm(x{k}-xopt)>norm(-x{k}-xopt)
                x{k}=-x{k};
            end
            error(i,k)=min(norm(x{k}-xopt),norm(-x{k}-xopt));
            cost(i,k)=x{k}'*Rtot*x{k};
        end
    end
    meancostmu1(:,:,MCiter)=cost;
    meanerrormu1(:,:,MCiter)=error;
    
    if rem(MCiter,10)==0
    save('alles_smalldim')
    end
end
save('alles_smalldim')
