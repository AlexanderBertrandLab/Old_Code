%% Creates sensor observations to use in a TLS problem
%% This file is used by PI_based_DTLS_DEMO.m

%  More info can be found in the papers

%  [1] A. Bertrand and M. Moonen, "Low-complexity distributed total least 
%  squares estimation in ad hoc sensor networks", 
%  internal report K.U. Leuven ESAT/SCD-SISTA

%  [2] A. Bertrand and M. Moonen "Consensus-based distributed total least
%  squares estimation in ad hoc wireless sensor networks", IEEE Trans.
%  Signal Proc., vol. 59, no. 5, pp. 2320-2330, 2011

%  and on the website http://homes.esat.kuleuven.be/~abertran


%% Copyright (c) 2011, Alexander Bertrand
% All rights reserved.
% Redistribution and use in source and binary forms, with or
% without modification, are permitted provided that the
% following conditions are met:
% 1) Redistributions of source code must retain the above copyright
% notice and this list of conditions.
% 2) Redistributions in binary form must reproduce the above copyright
% notice and this list of conditions in the documentation and/or other
% materials provided with the distribution.
% 3) The name of its contributors may not be used to endorse or promote
% products derived from this software without specific prior written
% permission.
%
% Contact: alexander.bertrand@esat.kuleuven.be (please report bugs)

 xopt=randn(xdim-1,1); %ground truth
 clear R
 Utot=[]; %noisy data matrix (stacked over all nodes)
 dtot=[]; %noisy response vector (stacked over all nodes)
 for k=1:nbnodes
     U=(randn(1))*randn(2*length(xopt),length(xopt)); %signal power (and SNR) is different in each sensor
     d=U*xopt;
     Unoisy=U+(0.5)*randn(size(U)); %add noise to data matrix
     dnoisy=d+(0.5)*randn(size(d)); %add noise to response vector
     TLSmatrix=[Unoisy -dnoisy]; %create extended data matrix
     R{k}=TLSmatrix'*TLSmatrix; 
     Utot=[Utot;Unoisy];
     dtot=[dtot;dnoisy];
 end
 xexact=xopt; %ground truth, new name
 xLS=inv(Utot'*Utot)*Utot'*dtot; %LS solution (=biased due to noise on U)