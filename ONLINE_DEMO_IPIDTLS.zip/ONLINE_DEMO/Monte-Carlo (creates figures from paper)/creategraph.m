%% This function creates a connection matrix for a random graph

%% Copyright (c) 2011, Alexander Bertrand
% All rights reserved.
% Redistribution and use in source and binary forms, with or
% without modification, are permitted provided that the
% following conditions are met:
% 1) Redistributions of source code must retain the above copyright
% notice and this list of conditions.
% 2) Redistributions in binary form must reproduce the above copyright
% notice and this list of conditions in the documentation and/or other
% materials provided with the distribution.
% 3) The name of its contributors may not be used to endorse or promote
% products derived from this software without specific prior written
% permission.
%
% Contact: alexander.bertrand@esat.kuleuven.be (please report bugs)

%% function congraph=creategraph(type,nbnodes,linkspernode);

%%  INPUTS:
%SCALAR     type            --> Number from 1 to 5, selecting the type of graph required (1=fully connected, 2=line topology, 3=tree topology, 4=random starting from tree, 5=random starting from chain)
%SCALAR     nbnodes         --> Required number of nodes in the graph
%SCALAR     linkspernode    --> Average number of links per node (only if type=4 or 5)

%%   OUTPUTS: 
%MATRIX     congraph        --> Connection matrix

%% Example input
% congraph=creategraph(4,20,3);

function congraph=creategraph(type,nbnodes,linkspernode);

if type==1
%fully connected graph
congraph=ones(nbnodes,nbnodes);

elseif type==2
%line topology graph
congraph=zeros(nbnodes,nbnodes);
for k=1:nbnodes
    if k~=nbnodes
    congraph(k,k+1)=1;
    end
    if k~=1
    congraph(k,k-1)=1;
    end
end

elseif type==3
%generate random tree
congraph=zeros(nbnodes,nbnodes);
for k=2:nbnodes
    q=floor((k-1)*rand(1))+1;
    congraph(k,q)=1;
    congraph(q,k)=1;
end

elseif type==4

%random connected graph (an average of n connections per node);
n=linkspernode;
%first, generate random tree
congraph=zeros(nbnodes,nbnodes);
for k=2:nbnodes
    q=floor((k-1)*rand(1))+1;
    congraph(k,q)=1;
    congraph(q,k)=1;
end
while mean(sum(congraph))<n
    %take random node and connect to another random node
    k=floor(nbnodes*rand(1))+1;
    q=floor(nbnodes*rand(1))+1;
    while congraph(k,q)==1 || k==q  %no existing links and no self loops
        k=floor(nbnodes*rand(1))+1;
        q=floor(nbnodes*rand(1))+1;
    end
    congraph(k,q)=1;
    congraph(q,k)=1;
end

elseif type==5

%random connected graph, starting from chain (an average of n connections per node);
n=linkspernode;
%first, generate a chain
congraph=zeros(nbnodes,nbnodes);
congraph(1,2)=1;
congraph(end,end-1)=1;
for k=2:nbnodes-1
    
    congraph(k,k-1)=1;
    %congraph(k,k)=1;
    congraph(k,k+1)=1;
end
while mean(sum(congraph))<n-2/nbnodes
    %take random node and connect to another random node
    k=floor(nbnodes*rand(1))+1;
    q=floor(nbnodes*rand(1))+1;
    while congraph(k,q)==1 || k==q  %no existing links and no self loops
        k=floor(nbnodes*rand(1))+1;
        q=floor(nbnodes*rand(1))+1;
    end
    congraph(k,q)=1;
    congraph(q,k)=1;
end

end

