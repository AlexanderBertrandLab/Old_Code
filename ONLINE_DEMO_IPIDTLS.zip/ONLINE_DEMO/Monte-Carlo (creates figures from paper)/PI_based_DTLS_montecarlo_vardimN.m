%% Simulate multiple Monte-Carlo experiments for IPI-D-TLS for different dimensions of the estimate

%%!!! code is not cleaned up (see folder 'Visual demo' for cleaner code)
%%!!! generates a large .mat file (>500 MB)
%%!!! run time can be hours/days

%% Copyright (c) 2011, Alexander Bertrand
% All rights reserved.
% Redistribution and use in source and binary forms, with or
% without modification, are permitted provided that the
% following conditions are met:
% 1) Redistributions of source code must retain the above copyright
% notice and this list of conditions.
% 2) Redistributions in binary form must reproduce the above copyright
% notice and this list of conditions in the documentation and/or other
% materials provided with the distribution.
% 3) The name of its contributors may not be used to endorse or promote
% products derived from this software without specific prior written
% permission.
%
% Contact: alexander.bertrand@esat.kuleuven.be (please report bugs)

% This is an attachement to the paper
%
%  [1] A. Bertrand and M. Moonen, "Low-complexity distributed total least squares estimation in ad hoc sensor networks"
%
%  More info on the website http://homes.esat.kuleuven.be/~abertran


clear all
close all

nbnodes=20;


nbMCruns=500;

fixedmu=1; %stepsize for grad descent
nbiters=800;
dimensions=[10 50 100 200];
meancost=zeros(nbiters,nbnodes,length(dimensions),nbMCruns);
meanerror=zeros(nbiters,nbnodes,length(dimensions),nbMCruns);



meanoptcost=0;

close all

for MCiter=1:nbMCruns
    MCiter
    
    congraph=creategraph(4,nbnodes,3);
    %1=fully connected
    %2=line topology
    %3=tree topology
    %4=random connected graph
    
    for p=1:length(dimensions)
    xdim=dimensions(p);
    createsystem;
    
    
    %%%Optimal solution
    Rtot=zeros(xdim,xdim);
    for k=1:nbnodes
        Rtot=Rtot+R{k};
        [u,s,a]=svd(R{k});
        mineigRk(k)=s(end,end);
    end
    [u,s,a]=svd(Rtot); 
    xopt=a(:,end);
    stot=s(end,end);
    %resolve sign ambiguity
    [nn,index]=max(abs(xopt));
    if xopt(index)<0
        xopt=-xopt;
    end
    optcost=xopt'*Rtot*xopt;
    meanoptcost=meanoptcost+optcost;
    
    

%%%%PI-based D-TLS, mu=0.2 *xdim/10
    clear P
    clear x
    
    for k=1:nbnodes
        P{k}=inv(R{k});
        x{k}=ones(xdim,1);
        x{k}=x{k}/norm(x{k});
    end
    error=zeros(nbiters,nbnodes);
    cost=zeros(nbiters,nbnodes);
    for i=1:nbiters
        mu=0.2*xdim/10;
        for k=1:nbnodes
            x{k}=P{k}*x{k};
            x{k}=x{k}/norm(x{k});
        end
        
        for k=1:nbnodes
            for n=1:nbnodes
                if congraph(k,n)==1 && k~=n
                    uv=sqrt(mu)*x{n};
                    uv2=P{k}*uv;
                    P{k}=P{k}+(1/(1-uv'*uv2))*uv2*uv2';
                end
            end
            uv=sqrt(mu*sum(congraph(k,:)))*x{k};
            uv2=P{k}*uv;
            P{k}=P{k}-(1/(1+uv'*uv2))*uv2*uv2';
        end
        for k=1:nbnodes
            if norm(x{k}-xopt)>norm(-x{k}-xopt)
                x{k}=-x{k};
            end
            error(i,k)=min(norm(x{k}-xopt),norm(-x{k}-xopt));
            cost(i,k)=x{k}'*Rtot*x{k};
        end
    end
    meancost(:,:,p,MCiter)=cost;
    meanerror(:,:,p,MCiter)=error;
    end
   
    
    
    save('alles_xdim')
end

