%%  Demo of IPI-D-TLS
%%  Version: 1.0


%  More info can be found in the paper
%
%  [1] A. Bertrand and M. Moonen, "Low-complexity distributed total least squares estimation in ad hoc sensor networks",
%  
%  and on the website http://homes.esat.kuleuven.be/~abertran


%% Copyright (c) 2011, Alexander Bertrand
% All rights reserved.
% Redistribution and use in source and binary forms, with or
% without modification, are permitted provided that the
% following conditions are met:
% 1) Redistributions of source code must retain the above copyright
% notice and this list of conditions.
% 2) Redistributions in binary form must reproduce the above copyright
% notice and this list of conditions in the documentation and/or other
% materials provided with the distribution.
% 3) The name of its contributors may not be used to endorse or promote
% products derived from this software without specific prior written
% permission.
%
% Contact: alexander.bertrand@esat.kuleuven.be (please report bugs)

%% Remarks
% 1) To make a new random WSN with random data: set demo_reproducable to 0,
% otherwise, the same demo is always shown

clear all
close all
demo_reproducable=1; %set to one if you want to use data from the demo_pidtls.mat file, otherwise a new random system is created


if demo_reproducable==1
    load demo_pidtls
else
    nbnodes=20; %number of nodes
    xdim=200; %dimension of x (variable that is estimated)
    
    %% create random graph
    %1=fully connected
    %2=line topology
    %3=tree topology
    %4=random connected graph
    congraph=creategraph(4,nbnodes,3);
    
    %% choose stepsize
    mu=2*xdim/100; %fixed stepsize for PI-based TLS
    
    %If (and only if) the data is generated with 'createsystem.m', the stepsize should be linearly
    %dependent on xdim since eigenvalues of R{k} increase with xdim, and
    %maximum stepsize is linearly dependent on the smallest eigenvalue of R{k}'s,
    %as shown in the paper:
    
    %   [2] A. Bertrand and M. Moonen "Consensus-based distributed total least
    %   squares estimation in ad hoc wireless sensor networks", IEEE Trans.
    %   Signal Proc., vol. 59, no. 5, pp. 2320-2330, 2011
    
    % However, in general, the size of the eigenvalues of R{k} do not depend on xdim.
    
    createsystem
    
end
nbiters=800; %number of iterations
shownode=1; %index of node you want to visualize

%%%Optimal solution
Rtot=zeros(xdim,xdim);
for k=1:nbnodes
    Rtot=Rtot+R{k};
end
[u,s,a]=svd(Rtot);
xopt=a(:,end);

%resolve sign ambiguity
[nn,index]=max(abs(xopt));
if xopt(index)<0
    xopt=-xopt;
end
optcost=xopt'*Rtot*xopt;
averr=zeros(nbiters,1); %vector containing average error (over all nodes)




%%%%Distributed computation
clear P
clear x

for k=1:nbnodes
    P{k}=inv(R{k});
    x{k}=ones(xdim,1);
    x{k}=x{k}/norm(x{k});
end

scrsz = get(0,'ScreenSize');
figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)])
set(gca,'FontSize',18)
error=zeros(nbiters,nbnodes);
cost=zeros(nbiters,nbnodes);
teller=1;
for i=1:nbiters
    
    
    for k=1:nbnodes
        x{k}=P{k}*x{k};
        x{k}=x{k}/norm(x{k});
    end
    
    for k=1:nbnodes
        for n=1:nbnodes
            if congraph(k,n)==1 && k~=n
                uv=sqrt(mu)*x{n};
                uv2=P{k}*uv;
                P{k}=P{k}+(1/(1-uv'*uv2))*uv2*uv2';
            end
        end
        uv=sqrt(mu*sum(congraph(k,:)))*x{k};
        uv2=P{k}*uv;
        P{k}=P{k}-(1/(1+uv'*uv2))*uv2*uv2';
    end
    for k=1:nbnodes
        if norm(x{k}-xopt)>norm(-x{k}-xopt)
            x{k}=-x{k};
        end
        error(i,k)=min(norm(x{k}-xopt),norm(-x{k}-xopt)); %error between ground truth and estimate
        cost(i,k)=x{k}'*Rtot*x{k}; %cost function that is minimized (See [1])
    end
    averr(i)=mean(error(i,:));
    disp(['iteration ' num2str(i) ' with average error ' num2str(averr(i))])
    if mean(cost(i,:))<1.001*optcost
        error=error(1:i,:);
        cost=cost(1:i,:);
        break
    end
    
    subplot(3,1,1)
    
    
    
    if i==1
        %Compute the local TLS solution if no cooperation (as a reference in the plots, is not used in the algorithm)
        for nodeind=1:nbnodes
            [u,s,a]=svd(R{nodeind});
            xinitial{nodeind}=a(:,end);
            if norm(xinitial{nodeind}-xopt)>norm(-xinitial{nodeind}-xopt)
                xinitial{nodeind}=-xinitial{nodeind};
            end
        end
    end
    
    plot(xopt,'b','LineWidth',1.5)
    hold on
    plot(x{shownode},'r','LineWidth',4,'Color',[.7 .7 .7])
    plot(xinitial{shownode},'r--','LineWidth',1.5)
    ylim([min(xopt) max(xopt)])
    hold off
    
    title(['Estimation at node ' num2str(shownode)])
    ylabel('estimate')
    xlabel('index of vector entry')
    legend('Network-wide TLS solution',['current estimate at node ' num2str(shownode)],['initial estimate at node ' num2str(shownode)])
    drawnow
    
    
    subplot(3,1,2)
    plot(error(:,shownode))
    title(['Error at node ' num2str(shownode)])
    ylabel('error')
    xlabel('iteration')
    subplot(3,1,3)
    
    plot(averr);
    title('Error averaged over all nodes')
    ylabel('error')
    xlabel('iteration')
end

figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)])
set(gca,'FontSize',18)
for k=1:min(nbnodes,5)
    subplot(min(nbnodes,5),1,k)
    set(gca,'FontSize',18)
    plot(error(:,k),'b','LineWidth',1.5)
    title(['error at node ' num2str(k)])
    ylabel('error')
    xlabel('iteration')
end

figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)/1.7])
set(gca,'FontSize',18)
hold on
plot(x{shownode},'--','LineWidth',4,'Color',[.65 .65 .65])
plot(xopt,'b','LineWidth',1)
plot(xinitial{shownode},'r:','LineWidth',1)
ylim([min(xopt) max(xopt)+0.1])
legend(['current estimate at node ' num2str(shownode)],'Network-wide TLS solution',['initial estimate at node ' num2str(shownode)],'Location','NorthWest')
legend boxoff
hold off


