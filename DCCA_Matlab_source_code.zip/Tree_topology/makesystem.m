%Initialisation of system

close all
D=10;    %dimension of latent random process

nbsensnode=6*ones(1,nbnodes); %number of sensors at each node (one element for each node)
noisepower=0.25; %additive spatially uncorrelated white noise with uniform distribution
nbsamples=50000; %number of observations per iteration of the DACMEE algorithm

nbsens=sum(nbsensnode); %total number of sensors

d1=rand(nbsamples,D); %random latent process
d1=d1-ones(nbsamples,1)*mean(d1);
for i=1:D
    d1(:,i)=fftfilt(ones(2*D-2*i+2,1),d1(:,i)); %different autocorrelation structure for each source
    %if i>3
    %    d1(:,i)=sqrt(0.5)*d1(:,i)/std(d1(:,i)); %interfering sources have half the power of other sources
    %else
        d1(:,i)=d1(:,i)/std(d1(:,i));
    %end
end



for k=1:nbnodes
    Ainit{k}=rand(D,nbsensnode(k))-0.5; %random mixture
    noise1{k}=sqrt(noisepower)*(rand(nbsamples,nbsensnode(k))); %random noise
    noise1{k}=noise1{k}-ones(nbsamples,1)*mean(noise1{k});
    
end




