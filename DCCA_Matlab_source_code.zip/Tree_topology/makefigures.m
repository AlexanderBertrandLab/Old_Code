%First run DCCA_tree before running this code
%this scripts generates the pictures from the paper in [1]


%     Copyright (C) 2013  Alexander Bertrand
%
%     This program is free software: you can redistribute it and/or modify
%     it under the terms of the GNU General Public License as published by
%     the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
%
%     This program is distributed in the hope that it will be useful,
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU General Public License for more details.
%
%     You should have received a copy of the GNU General Public License
%     along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Contact information of the author (please report bugs):
% alexander.bertrand@esat.kuleuven.be
% http://homes.esat.kuleuven.be/~abertran

%%%  REFERENCES %%%
%[1] A. Bertrand and M. Moonen, "Distributed canonical correlation analysis in wireless sensor networks with application to distributed blind source separation", IEEE Trans. Signal Processing, 2015

close all
clear all

load simresults
 showiters=200;
 
 fonts=18;
 fontslegend=20;
 scrsz = get(0,'ScreenSize');
figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)])

subplot(2,1,1)
for n=1:size(Vnormser,2)
p2{n}=mean(SERser{1,n}(1:MCrun,1:showiters),1);
p3{n}=mean(SERopt{1,n}(1:MCrun));
end
plot(p2{1},'r','LineWidth',2);
hold on
plot(p3{1}*ones(length(p2{1})),'r--','LineWidth',2);
plot(p2{2},'k','LineWidth',2);
%plot(p3{2}*ones(length(p2{2})),'k--','LineWidth',2);
plot(p2{3},'b','LineWidth',2);
%plot(p3{3}*ones(length(p2{2})),'b--','LineWidth',2);

xlabel('iteration','Interpreter','latex','Fontsize',fonts)
ylabel('SER [dB]','Interpreter','latex','Fontsize',fonts)

set(gca,'Fontsize',fonts)
 h=legend('DCCA','centralized CCA');
 set(h,'Fontsize',fontslegend,'Location','SouthEast')
 

subplot(2,1,2)
for n=1:size(Vnormser,2)
p1{n}=quantile(Vnormser{1,n}(1:MCrun,1:showiters),[.25 .5 .75],1);
end
    semilogy(p1{1}(2,:),'r','LineWidth',2);
    hold on
    semilogy(p1{1}(1,:),'r--','LineWidth',2);
    semilogy(p1{1}(3,:),'r--','LineWidth',2);
    
    %semilogy(p1{2}(2,:),'k','LineWidth',2);
    %semilogy(p1{2}(1,:),'k--','LineWidth',2);
    %semilogy(p1{2}(3,:),'k--','LineWidth',2);
    
    semilogy(p1{3}(2,:),'b','LineWidth',2);
    semilogy(p1{3}(1,:),'b--','LineWidth',2);
    semilogy(p1{3}(3,:),'b--','LineWidth',2);
    

xlabel('iteration','Interpreter','latex','Fontsize',fonts)
ylabel('MSE over entries of $\mathbf{V}^i$','Interpreter','latex','Fontsize',fonts)
ylim([3e-5 0.9e-2])
set(gca,'Fontsize',fonts)
 h=legend('Median','25% and 75% percentiles');
 set(h,'Fontsize',fontslegend,'Location','NorthEast')

clear p1
clear p2
clear p3
figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)])

subplot(2,1,1)
for n=1:size(Vnormser,1)
p2{n}=mean(SERser{n,1}(1:MCrun,1:showiters),1);
p3{n}=mean(SERopt{n,1}(1:MCrun));
end
plot(p2{1},'r','LineWidth',2);
hold on
plot(p3{1}*ones(length(p2{1})),'r--','LineWidth',2);
plot(p2{2},'k','LineWidth',2);
plot(p3{2}*ones(length(p2{2})),'k--','LineWidth',2);
plot(p2{3},'b','LineWidth',2);
plot(p3{3}*ones(length(p2{2})),'b--','LineWidth',2);

xlabel('iteration','Interpreter','latex','Fontsize',fonts)
ylabel('SER [dB]','Interpreter','latex','Fontsize',fonts)

set(gca,'Fontsize',fonts)

 h=legend('DCCA','centralized CCA');
 set(h,'Fontsize',fontslegend,'Location','SouthEast')


subplot(2,1,2)
for n=1:size(Vnormser,1)
p1{n}=quantile(Vnormser{n,1}(1:MCrun,1:showiters),[.25 .5 .75],1);
end
    semilogy(p1{1}(2,:),'r','LineWidth',2);
    hold on
    semilogy(p1{1}(1,:),'r--','LineWidth',2);
    semilogy(p1{1}(3,:),'r--','LineWidth',2);
    
    %semilogy(p1{2}(2,:),'k','LineWidth',2);
    semilogy(p1{3}(2,:),'b','LineWidth',2);
    
    %semilogy(p1{2}(1,:),'k--','LineWidth',2);
    %semilogy(p1{2}(3,:),'k--','LineWidth',2);
    
    semilogy(p1{3}(1,:),'b--','LineWidth',2);
    semilogy(p1{3}(3,:),'b--','LineWidth',2);
    
xlabel('iteration','Interpreter','latex','Fontsize',fonts)
ylabel('MSE over entries of $\mathbf{V}^i$','Interpreter','latex','Fontsize',fonts)
ylim([0.9e-5 2e-2])


set(gca,'Fontsize',fonts)
 h=legend('Median','25% and 75% percentiles');
 set(h,'Fontsize',fontslegend,'Location','NorthEast')


