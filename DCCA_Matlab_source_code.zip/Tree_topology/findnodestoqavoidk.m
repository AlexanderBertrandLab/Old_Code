%This function is applied to check if a node t has a path to node q that
%does not contain k

%     Copyright (C) 2013  Alexander Bertrand
%
%     This program is free software: you can redistribute it and/or modify
%     it under the terms of the GNU General Public License as published by
%     the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
%
%     This program is distributed in the hope that it will be useful,
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU General Public License for more details.
%
%     You should have received a copy of the GNU General Public License
%     along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Contact information of the author (please report bugs):
% alexander.bertrand@esat.kuleuven.be
% http://homes.esat.kuleuven.be/~abertran


%function [checkflag]=findnodestoqavoidk(checkflag,terminated,connectionmatrix,t,q,k)

%Inputs:
%checkflag        = must be 1 at first call
%terminated         =J-dim vector with a 1 at indices of all nodes that are already visited
%                   should be all-zero in first call
%connectionmatrix   = if element (i,j)==1, this means that there is an arc 
%                   from node i to node j.
%t                  = node in which the path starts
%q                  = node to which a path has to be found
%k                  = node through which the path cannot go

%Outputs:
%checkflag              = 1 if a path has found from t to q without passing k, 0
%                   otherwise

function [checkflag,terminated]=findnodestoqavoidk(checkflag,terminated,connectionmatrix,t,q,k)
terminated(t)=1;
if t==k
    checkflag=0;
    terminated=ones(length(terminated),1);
elseif t==q
    checkflag=1;
    terminated=ones(length(terminated),1);
else
    neighbours=find(connectionmatrix(t,:).*(1-terminated')==1);
    for j=neighbours
        [temp,terminated]=findnodestoqavoidk(checkflag,terminated,connectionmatrix,j,q,k);
        checkflag=checkflag*temp;
    end
end
end