%%  Monte-Carlo simulations of DCCA in fully-connected WSNs

%%  Version: 1.0

%     Copyright (C) 2013  Alexander Bertrand
%
%     This program is free software: you can redistribute it and/or modify
%     it under the terms of the GNU General Public License as published by
%     the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
%
%     This program is distributed in the hope that it will be useful,
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU General Public License for more details.
%
%     You should have received a copy of the GNU General Public License
%     along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Contact information of the author (please report bugs):
% alexander.bertrand@esat.kuleuven.be
% http://homes.esat.kuleuven.be/~abertran

%%%  REFERENCES %%%
%[1] A. Bertrand and M. Moonen, "Distributed canonical correlation analysis in wireless sensor networks with application to distributed blind source separation", IEEE Trans. Signal Processing, 2015



%% NOTE: this code may take a very long time to finish. Reduce nbMCruns to reduce simulation time

clear all
close all

nbMCruns=300; %number of MC runs
BSSscenario=1; %set to 1 if a BSS scenario needs to be simulated
showplots=1; %set to 1 if you want visual feedback
nbiter=50; %number of DCCA iterations

tellernodes=0;
for nbnodes=[10 20 40] %simulate for networks with different number of nodes
    tellernodes=tellernodes+1;
    
    
    if nbnodes==10
        Qrange=[1:3]; %which values of Q need to be simulated
    else
        Qrange=1;
    end
    
    for MCrun=1:nbMCruns
        tellerQ=0;
        for Q=Qrange %simulate for different number of eigenvectors (Q in paper)
            [MCrun Q nbnodes]
            tellerQ=tellerQ+1;
            
            if MCrun==1
                Vnormser{tellernodes,tellerQ}=zeros(nbMCruns,nbiter); %track MSE with respect to true value of CCA directions
                Wnormser{tellernodes,tellerQ}=zeros(nbMCruns,nbiter); %track MSE with respect to true value of CCA directions
                Jopt{tellernodes,tellerQ}=zeros(nbMCruns,1); %optimal value of objective function Tr(V^H Rxy W)
                Jser{tellernodes,tellerQ}=zeros(nbMCruns,nbiter); %track value of objective function Tr(V^H Rxy W)
                SERopt{tellernodes,tellerQ}=zeros(nbMCruns,1); %optimal value of SER of BSS reconstruction
                SERser{tellernodes,tellerQ}=zeros(nbMCruns,nbiter); %track value of SER of BSS reconstruction
            end
            
            tic
            
            if tellerQ==1
                makesystem %create data (only once for different Q)
            end
            
            
            clear dnode
            clear X
            clear Y
            
            %compute observations for each node
            for k=1:nbnodes
                A{k}=Ainit{k}(:,1:nbsensnode(k));
                X{k}=d1*A{k}+noise1{k};
                if BSSscenario==1
                    nblags=3;
                    Y{k}=[];
                    for j=1:nblags
                        Y{k}=[Y{k} X{k}(j+1:end-nblags+j,:)];
                    end
                    
                    X{k}=X{k}(1:size(Y{k},1),:);
                else
                    Y{k}=X{k}(:,2:2:end);
                    X{k}=X{k}(:,1:2:end-1);
                end
                
                nbsensnodeX(k)=size(X{k},2); %number of sensors for variable x
                nbsensnodeY(k)=size(Y{k},2); %number of sensors for variable y
            end
            if BSSscenario==1
                to_be_extracted=d1(1:size(Y{1},1),1:Q); %sources with largest autocorrelation at timelag 1, to be extracted with BSS
            end
            
            nbsensX=sum(nbsensnodeX); %total number of sensors for variable x
            nbsensY=sum(nbsensnodeY); %total number of sensors for variable y
            
            Xfull=[]; %full vector x
            Yfull=[]; %full vector y
            for k=1:nbnodes
                Xfull=[Xfull X{k}];
                Yfull=[Yfull Y{k}];
            end
            nbsamples=size(Xfull,1);
            
            %%Optimal solution:
            
            %NOTE: the CCA is here computed manually, but it can also be
            %computed using the matlab function canoncorr
            Rxx=1/nbsamples*conj(Xfull'*Xfull);
            Ryy=1/nbsamples*conj(Yfull'*Yfull);
            Rxy=1/nbsamples*conj(Xfull'*Yfull);
            R1=Rxy*(Ryy\Rxy'); %not perfectly symmetric due to numerical errors
            R1=0.5*(R1+R1'); %make perfectly symmetric
            R2=Rxy'*(Rxx\Rxy); %not perfectly symmetric due to numerical errors
            R2=0.5*(R2+R2');  %make perfectly symmetric
            [B,s]=eig(R1,Rxx); %if R1 and Rxx are symmetric (Hermitian), then the columns of B are automatically scaled such that B'*Rxx*B=identity matrix
            [notneeded,ind]=sort(abs(diag(s)),'descend');
            vopt=B(:,ind(1:Q)); %if sources have different autocorrelation, then xopt is a BSS demixing matrix for x
            [B,s]=eig(R2,Ryy);
            [magweg,ind]=sort(abs(diag(s)),'descend');
            wopt=B(:,ind(1:Q)); %if sources have different autocorrelation, then wopt is a BSS demixing matrix for y
            %note: in the BSS with single timelag: same solution for vopt
            %and wopt can be enforced by computing the GEVD of the
            %symmetric Rxy matrix
            Jopt{tellernodes,tellerQ}(MCrun)=trace(abs(vopt'*Rxy*wopt))/nbsamples; %optimal value of objective function
            
            if BSSscenario==1
                %evaluate BSS reconstruction
                reconstruction=Xfull*vopt(:,1:Q); %reconstructed source
                reconstruction_CCA=reconstruction;
                scaling=(reconstruction'*to_be_extracted)./(reconstruction'*reconstruction); %resolve scaling ambiguity
                reconstruction=reconstruction*diag(diag(scaling));
                reconstruction_CCA=reconstruction;
                SERopt{tellernodes,tellerQ}(MCrun,1)=10*log10(var(to_be_extracted(:,1))/var(reconstruction(:,1)-to_be_extracted(:,1))); %SER for centralized BSS
            end
            
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%                     DCCA algorithm
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            clear v
            clear w
            clear V
            clear W
            
            vinit=randn(size(vopt)); %random initialization
            winit=randn(size(wopt)); %random initialization
            tellerX=1;
            tellerY=1;
            for k=1:nbnodes
                V{k}=vinit(tellerX:tellerX+nbsensnodeX(k)-1,:); % V_k^i from the paper
                W{k}=winit(tellerY:tellerY+nbsensnodeY(k)-1,:); % W_k^i from the paper
                tellerX=tellerX+nbsensnodeX(k);
                tellerY=tellerY+nbsensnodeY(k);
            end
            v=vinit; %full V^i from the paper
            w=winit; %full W^i from the paper
            
            clear teller
            for i=0:nbiter-1
                k=rem(i,nbnodes)+1;
                
                %update node k
                
                CompressorX=blkdiag(eye(nbsensnodeX(k)),V{1:k-1},V{k+1:end});
                Xmink=horzcat(X{1:k-1},X{k+1:end});
                Xcompressed=horzcat(X{k},Xmink*conj(blkdiag(V{1:k-1},V{k+1:end}))); %xtilde in the paper
                CompressorY=blkdiag(eye(nbsensnodeY(k)),W{1:k-1},W{k+1:end});
                Ymink=horzcat(Y{1:k-1},Y{k+1:end});
                Ycompressed=horzcat(Y{k},Ymink*conj(blkdiag(W{1:k-1},W{k+1:end}))); %ytilde in the paper
                
                %NOTE: the CCA is here computed manually, but it can also be
                %computed using the matlab function canoncorr
                Rxxcompressed=1/nbsamples*conj(Xcompressed'*Xcompressed); %R_{xtilde xtilde} in the paper
                Ryycompressed=1/nbsamples*conj(Ycompressed'*Ycompressed); %R_{ytilde ytilde} in the paper
                Rxycompressed=1/nbsamples*conj(Xcompressed'*Ycompressed); %R_{xtilde ytilde} in the paper
                
                R1compressed=Rxycompressed*(Ryycompressed\Rxycompressed'); %not perfectly symmetric due to numerical errors
                R1compressed=0.5*(R1compressed+R1compressed'); %make perfectly symmetric
                R2compressed=Rxycompressed'*(Rxxcompressed\Rxycompressed); %not perfectly symmetric due to numerical errors
                R2compressed=0.5*(R2compressed+R2compressed'); %make perfectly symmetric
                [B,s]=eig(R1compressed,Rxxcompressed);
                [notneeded,ind]=sort(abs(diag(s)),'descend');
                VGnew=B(:,ind(1:Q)); %select Q principal eigenvectors
                Vkold=V{k};
                V{k}=VGnew(1:nbsensnodeX(k),:); %new estimate of V_k^{i+1}
                [B,s]=eig(R2compressed,Ryycompressed);
                [notneeded,ind]=sort(abs(diag(s)),'descend');
                WHnew=B(:,ind(1:Q)); %select Q principal eigenvectors
                Wkold=W{k};
                W{k}=WHnew(1:nbsensnodeY(k),:); %new estimate of W_k^{i+1}
                
                
                %resolve sign ambiguity (internally, only needed for evaluation)
                for q=1:Q
                    if sum(sum((Vkold(:,q)-V{k}(:,q)).^2))>sum(sum((-Vkold(:,q)-V{k}(:,q)).^2))
                        V{k}(:,q)=-V{k}(:,q);
                        VGnew(:,q)=-VGnew(:,q);
                    end
                    if sum(sum((Wkold(:,q)-W{k}(:,q)).^2))>sum(sum((-Wkold(:,q)-W{k}(:,q)).^2))
                        W{k}(:,q)=-W{k}(:,q);
                        WHnew(:,q)=-WHnew(:,q);
                    end
                end
                
                teller=1;
                for q=1:k-1
                    V{q}=V{q}*VGnew(nbsensnodeX(k)+teller:nbsensnodeX(k)+teller+Q-1,:);
                    W{q}=W{q}*WHnew(nbsensnodeY(k)+teller:nbsensnodeY(k)+teller+Q-1,:);
                    teller=teller+Q;
                end
                for q=k+1:nbnodes
                    V{q}=V{q}*VGnew(nbsensnodeX(k)+teller:nbsensnodeX(k)+teller+Q-1,:);
                    W{q}=W{q}*WHnew(nbsensnodeY(k)+teller:nbsensnodeY(k)+teller+Q-1,:);
                    teller=teller+Q;
                end
                
                % Stack the V{k}'s and W{k}'s to obtain network-wide vectors
                tellerX=1;
                tellerY=1;
                for q=1:nbnodes
                    v(tellerX:tellerX+nbsensnodeX(q)-1,:)=V{q}(:,1:Q);
                    w(tellerY:tellerY+nbsensnodeY(q)-1,:)=W{q}(:,1:Q);
                    tellerX=tellerX+nbsensnodeX(q);
                    tellerY=tellerY+nbsensnodeY(q);
                end
                
                %resolve sign ambiguity (for plotting)
                for q=1:Q
                    if sum(sum((vopt(:,q)-v(:,q)).^2))>sum(sum((-vopt(:,q)-v(:,q)).^2))
                        v(:,q)=-v(:,q);
                    end
                    if sum(sum((wopt(:,q)-w(:,q)).^2))>sum(sum((-wopt(:,q)-w(:,q)).^2))
                        w(:,q)=-w(:,q);
                    end
                end
                
                Jser{tellernodes,tellerQ}(MCrun,i+1)=trace(abs(v'*Rxy*w))/nbsamples;
                Vnormser{tellernodes,tellerQ}(MCrun,i+1)= sum(sum(abs(vopt-v).^2))/(size(v,1)*size(v,2));
                Wnormser{tellernodes,tellerQ}(MCrun,i+1)= sum(sum(abs(wopt-w).^2))/(size(w,1)*size(w,2));
                
                if BSSscenario==1
                    %evaluate BSS reconstruction
                    reconstruction=Xfull*v(:,1:Q); %reconstructed source
                    scaling=(reconstruction'*to_be_extracted)./(reconstruction'*reconstruction); %resolve scaling ambiguity
                    reconstruction=reconstruction*diag(diag(scaling));
                    SERser{tellernodes,tellerQ}(MCrun,i+1)=10*log10(var(to_be_extracted(:,1))/var(reconstruction(:,1)-to_be_extracted(:,1)));
                    if i==nbiter-1 && MCrun==1 && Q==3
                        reconstruction_DCCA=reconstruction;
                        save('simresults_1MCrun_new','reconstruction_DCCA','reconstruction_CCA','to_be_extracted')
                    end
                end
                
                if showplots==1
                    %%% Show intermediate plot of estimate (only first column of v)
                    plot(vopt(:,1),'r')
                    hold on
                    plot(v(:,1))
                    ylim([1.2*min(real(vopt(:,1))) 1.2*max(real(vopt(:,1)))]);
                    hold off
                    title(['Iteration #' num2str(i+1) '/' num2str(nbiter)])
                    drawnow
                end
                
            end
            
            
            MCrun
            if rem(MCrun,20)==0 %save once in a while
                save('simresults','Jser','Jopt','Vnormser','Wnormser','SERopt','SERser','nbiter','MCrun')
            end
            
        end
        toc
        
    end
end
save('simresults','Jser','Jopt','Vnormser','Wnormser','SERopt','SERser','nbiter','MCrun')

