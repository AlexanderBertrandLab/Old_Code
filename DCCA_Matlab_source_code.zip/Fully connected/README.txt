Run the files in Matlab in this order:

1) DCCA_fullycon.m
2) makefigures.m

(makesystem.m is a supporting file, and is called in DCCA_fullycon.m)

PS: DCCA_fullycon may take a long time to run, decrease number of Monte-Carlo runs to reduce simulation time


%     Copyright (C) 2013  Alexander Bertrand
%
%     This program is free software: you can redistribute it and/or modify
%     it under the terms of the GNU General Public License as published by
%     the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
%
%     This program is distributed in the hope that it will be useful,
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU General Public License for more details.
%
%     You should have received a copy of the GNU General Public License
%     along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Contact information of the author (please report bugs):
% alexander.bertrand@esat.kuleuven.be
% http://homes.esat.kuleuven.be/~abertran

%%%  REFERENCES %%%
%[1] A. Bertrand and M. Moonen, "Distributed canonical correlation analysis in wireless sensor networks with application to distributed blind source separation", IEEE Trans. Signal Processing, 2015




